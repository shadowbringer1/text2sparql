# LC-QuAD2.0
A large data set of natural language queries with corresponding SPARQL queries for Wikidata and Dbpedia2018
